// models/Keyword.js
const mongoose = require('mongoose');

const keywordSchema = new mongoose.Schema({
  keyword: { type: String, required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, // Reference to the user who added the keyword
  rankings: [
    {
      position: Number,
      date: { type: Date, default: Date.now },
    },
  ],
  lastChecked: { type: Date, default: Date.now }, // When the keyword was last checked
});

module.exports = mongoose.model('Keyword', keywordSchema);

// Example API call to fetch keyword rank (update this with the actual API)
const fetchKeywordRank = async (keyword) => {
  // Replace with actual API call logic
  return Math.floor(Math.random() * 100); // Simulating a random position
};

// Integrate this function in your cron job or route handlers to update rankings