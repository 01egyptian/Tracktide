// routes/keywords.js
const express = require('express');
const axios = require('axios');
const Keyword = require('../models/Keyword');
const router = express.Router();

// Add a new keyword
router.post('/', async (req, res) => {
  const { keyword, userId } = req.body;

  try {
    const newKeyword = new Keyword({ keyword, user: userId });
    await newKeyword.save();
    res.status(201).json(newKeyword);
  } catch (error) {
    res.status(400).json({ error: 'Error adding keyword' });
  }
});

// Get all keywords for a user
router.get('/:userId', async (req, res) => {
  try {
    const keywords = await Keyword.find({ user: req.params.userId });
    res.json(keywords);
  } catch (error) {
    res.status(400).json({ error: 'Error fetching keywords' });
  }
});

// Update keyword rankings
router.post('/update', async (req, res) => {
  const { keywordId, position } = req.body;

  try {
    const keyword = await Keyword.findById(keywordId);
    if (!keyword) return res.status(404).json({ error: 'Keyword not found' });

    keyword.rankings.push({ position });
    keyword.lastChecked = Date.now();
    await keyword.save();

    res.json(keyword);
  } catch (error) {
    res.status(400).json({ error: 'Error updating keyword' });
  }
});

module.exports = router;