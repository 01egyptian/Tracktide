// server.js
const express = require('express'); // Import Express framework
const mongoose = require('mongoose'); // Import Mongoose for MongoDB
const dotenv = require('dotenv'); // Import dotenv for environment variables
const cors = require('cors'); // Import CORS middleware
const keywordRoutes = require('./seo-keyword-tracker/routes/keywords');
const authRoutes = require('./seo-keyword-tracker/routes/auth');

dotenv.config(); // Load environment variables from .env file
const app = express(); // Create an instance of Express
app.use(cors()); // Enable CORS
app.use(express.json()); // Parse incoming JSON requests

// Connect to MongoDB using Mongoose

const connectDB =  async ()=>{

  try{
      const conn = await mongoose.connect(process.env.MONGO_URI,{
          //must add in order to not get any error masseges:
          useUnifiedTopology:true,
          useNewUrlParser: true,
          useCreateIndex: true
      })
      console.log(`mongo database is connected!!! ${conn.connection.host} `)
  }catch(error){
      console.error(`Error: ${error} `)
      process.exit(1) //passing 1 - will exit the proccess with error
  }

}


// Define API routes
app.use('/api/keywords', keywordRoutes); // Set up keyword-related routes
app.use('/api/auth', authRoutes); // Set up authentication-related routes

// Define the port and start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));


const cron = require('node-cron');
const Keyword = require('./models/Keyword');

// Schedule to run every day at midnight
cron.schedule('0 0 * * *', async () => {
  console.log('Running scheduled task to update keyword rankings');
  // Add logic to fetch keyword rankings and update database here
});